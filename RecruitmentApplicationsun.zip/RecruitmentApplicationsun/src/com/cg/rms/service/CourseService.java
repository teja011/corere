package com.cg.rms.service;

import java.util.List;







import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.exception.RecruitmentException;


public interface CourseService {
	
	String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	String insertCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException;
	String insertCandidateWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
	List<CandidateBeanPersonal> getAllCourses() throws RecruitmentException;
	boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	boolean updateCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException;
	boolean updatCandidateWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
	
	public int login(String username, String password, String role) throws RecruitmentException;
	
	String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException;
	boolean updateCompanyDetails() throws RecruitmentException;
	
	/*boolean deleteCourse(long cource_id) throws CourseException;*/
	/*boolean validate(Course cource) throws CourseException;*/
}
